from flask import Flask, render_template

app = Flask(__name__)
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)

@app.route('/items')
def items():
    fake_items = [
    {'name': 'apple', 'desc':'This is an apple', 'price': 1.99},
    {'name': 'banana', 'desc':'This is a banana','price': 0.99},
    {'name': 'orange', 'desc':'This is an orange', 'price': 2.99}
    ]
    return render_template('items.html', items=fake_items)

from analysis.scatter_m import data_analysis
@app.route('/static_chart')
def static_chart():
    img =data_analysis()
    return render_template('static_chart.html', img=img)

# python app.py
if __name__ == '__main__':
    # run the app in debug mode True on port 5000
    app.run(debug=True, host='0.0.0.0', port=5000)