import matplotlib.pyplot as plt
import numpy as np
import os
plt.style.use('_mpl-gallery')
def data_analysis():
    # make the fakedata
    np.random.seed(3)
    x = 4 + np.random.normal(0, 2, 24)
    y = 4 + np.random.normal(0, 2, len(x))
    # size and color:
    sizes = np.random.uniform(15, 80, len(x))
    colors = np.random.uniform(15, 80, len(x))
    # plot
    fig, ax = plt.subplots()
    ax.scatter(x, y, s=sizes, c=colors, vmin=0, vmax=100)
    ax.set(xlim=(0, 8), xticks=np.arange(1, 8),
    ylim=(0, 8), yticks=np.arange(1, 8))
    # get the parent diretory
    parent_path=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    file_name = 'scatter_m.png'
    #
    file_path = parent_path + '/static/imgs/'+ file_name
    # save the figure
    plt.savefig(file_path, dpi=300)
    return file_name